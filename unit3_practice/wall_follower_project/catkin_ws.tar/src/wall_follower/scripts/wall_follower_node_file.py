#! /usr/bin/env python


import rospy
from std_msgs.msg import Int32
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan


rospy.init_node('wall_follower_node')
pub = rospy.Publisher('/cmd_vel', Twist, queue_size=1)
rate = rospy.Rate(2)

command = Twist()


def callback(msg):

    if(msg.ranges[90] >= 0.5 and msg.ranges[2] < 0.3 and msg.ranges[2] > 0.2):
        # go striaght
        command.linear.x = 0.1
        command.linear.y = 0
        command.angular.z = 0.0
    elif(msg.ranges[90] >= 0.5 and msg.ranges[2] > 0.3):
        # go right
        command.linear.x = 0.1
        command.linear.y = 0
        command.angular.z = -0.2
    else:
        # go left
        command.linear.x = 0.1
        command.linear.y = 0
        command.angular.z = 0.4


sub = rospy.Subscriber('/scan', LaserScan, callback)


while not rospy.is_shutdown():
    pub.publish(command)
    rate.sleep()
